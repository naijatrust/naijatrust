-- NaijaTrust initial database schema (review before running)
-- Run this in Supabase SQL Editor only after creating a project.
-- Public visitors can read approved business profiles. Authenticated users can manage only their own profiles.
-- This schema deliberately does not include public order records or evidence uploads.

create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 120),
  category text not null check (char_length(category) between 2 and 80),
  description text not null default '' check (char_length(description) <= 1200),
  city text not null default '' check (char_length(city) <= 100),
  public_contact text not null default '' check (char_length(public_contact) <= 160),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.businesses enable row level security;

-- Anyone can read approved listings only.
drop policy if exists "Anyone can read approved businesses" on public.businesses;
create policy "Anyone can read approved businesses"
on public.businesses for select
using (status = 'approved');

-- Signed-in owners can create their own listing, initially pending review.
drop policy if exists "Owners can submit own businesses" on public.businesses;
create policy "Owners can submit own businesses"
on public.businesses for insert to authenticated
with check (auth.uid() = owner_id and status = 'pending');

-- Owners can update their own listing, but cannot approve themselves.
drop policy if exists "Owners can update own pending businesses" on public.businesses;
create policy "Owners can update own pending businesses"
on public.businesses for update to authenticated
using (auth.uid() = owner_id and status = 'pending')
with check (auth.uid() = owner_id and status = 'pending');

-- Reviews, private orders, complaint evidence and admin approval workflows are intentionally
-- not created here. They need separate abuse prevention, privacy rules, and moderation design.
